#include "ui_applist.h"
#include "app_scanner.h"
#include <gtk/gtk.h>
#include <time.h>

/* Application identifier */
#define APP_ID "dev.jeyaulhoque.appclipmanager"
#define APP_TITLE "AppClip Manager"
#define APP_VERSION "1.0.0"
#define AUTHOR_NAME "Jeyaul Hoque"
#define AUTHOR_WEBSITE "https://jeyaulhoque.pages.dev/"

/**
 * Custom CSS for modern styling: badges, rounded buttons, toast notification.
 */
static const char *CUSTOM_CSS =
    "list row {"
    "   border-bottom: 1px solid alpha(#94a3b8, 0.25);"
    "   padding: 4px;"
    "   transition: background-color 150ms ease-in-out;"
    "}"
    "list row:hover {"
    "   background-color: alpha(#3b82f6, 0.08);"
    "}"
    "list row:selected {"
    "   background-color: alpha(#3b82f6, 0.16);"
    "}"
    ".pkg-badge {"
    "   font-size: 11px;"
    "   font-weight: bold;"
    "   padding: 2px 8px;"
    "   border-radius: 12px;"
    "}"
    ".badge-apt {"
    "   background-color: #dbeafe;"
    "   color: #1e40af;"
    "   border: 1px solid #bfdbfe;"
    "}"
    ".badge-snap {"
    "   background-color: #ffedd5;"
    "   color: #9a3412;"
    "   border: 1px solid #fed7aa;"
    "}"
    ".badge-flatpak {"
    "   background-color: #e0e7ff;"
    "   color: #3730a3;"
    "   border: 1px solid #c7d2fe;"
    "}"
    ".badge-desktop {"
    "   background-color: #f1f5f9;"
    "   color: #475569;"
    "   border: 1px solid #cbd5e1;"
    "}"
    ".size-label {"
    "   color: #64748b;"
    "   font-size: 12px;"
    "}"
    ".toast-container {"
    "   background-color: #0f172a;"
    "   color: #f8fafc;"
    "   border-radius: 20px;"
    "   padding: 8px 18px;"
    "   margin-bottom: 16px;"
    "   box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);"
    "}"
    ".btn-uninstall {"
    "   padding: 5px 14px;"
    "   font-weight: 500;"
    "   border-radius: 6px;"
    "}"
    "button.destructive-action {"
    "   background-image: none;"
    "   background-color: #ef4444;"
    "   color: #ffffff;"
    "   border: 1px solid #dc2626;"
    "}"
    "button.destructive-action:hover {"
    "   background-color: #dc2626;"
    "}"
    "headerbar {"
    "   border-bottom: 1px solid #e2e8f0;"
    "}";

/**
 * Loads custom application CSS into default GTK screen.
 */
static void apply_application_css(void)
{
    GtkCssProvider *provider = gtk_css_provider_new();
    gtk_css_provider_load_from_data(provider, CUSTOM_CSS, -1, NULL);

    GdkScreen *screen = gdk_screen_get_default();
    if (screen) {
        gtk_style_context_add_provider_for_screen(
            screen,
            GTK_STYLE_PROVIDER(provider),
            GTK_STYLE_PROVIDER_PRIORITY_APPLICATION
        );
    }
    g_object_unref(provider);
}

/**
 * Displays the About dialog as required.
 * Mentions created by Jeyaul Hoque, website https://jeyaulhoque.pages.dev/
 * and loads logo from /usr/share/appclip-manager/logo.png or ./assets/logo.png.
 */
static void show_about_dialog(GtkWindow *parent)
{
    const char *logo_locations[] = {
        "/usr/share/appclip-manager/logo.png",
        "./assets/logo.png",
        "assets/logo.png",
        NULL
    };

    GdkPixbuf *logo_pixbuf = NULL;
    for (int i = 0; logo_locations[i]; i++) {
        if (g_file_test(logo_locations[i], G_FILE_TEST_EXISTS)) {
            GError *err = NULL;
            logo_pixbuf = gdk_pixbuf_new_from_file_at_scale(logo_locations[i], 128, 128, TRUE, &err);
            if (logo_pixbuf) break;
            if (err) g_error_free(err);
        }
    }

    const char *authors[] = {
        AUTHOR_NAME,
        NULL
    };

    gtk_show_about_dialog(
        parent,
        "program-name", APP_TITLE,
        "version", APP_VERSION,
        "comments", "Part 1: Installed Applications Manager\n"
                    "Manage APT, Snap, Flatpak, and Desktop Applications with ease.",
        "website", AUTHOR_WEBSITE,
        "website-label", "Jeyaul Hoque — Official Website",
        "authors", authors,
        "logo", logo_pixbuf,
        "copyright", "© 2026 Jeyaul Hoque. All rights reserved.",
        "license-type", GTK_LICENSE_GPL_3_0,
        NULL
    );

    if (logo_pixbuf) {
        g_object_unref(logo_pixbuf);
    }
}

/**
 * Signal callback for the About menu item.
 */
static void on_about_clicked(GtkMenuItem *item, gpointer user_data)
{
    (void)item;
    UiAppContext *ctx = (UiAppContext *)user_data;
    show_about_dialog(GTK_WINDOW(ctx->window));
}

/**
 * Scan completion callback invoked on the GTK main thread.
 */
static void on_scan_finished(GPtrArray *apps, const char *status_msg, gpointer user_data)
{
    UiAppContext *ctx = (UiAppContext *)user_data;
    (void)status_msg;

    /* Stop busy indicators */
    ui_applist_set_busy_state(ctx, FALSE, NULL);

    /* Populate list */
    ui_applist_populate(ctx, apps);
}

/**
 * Initiates an asynchronous refresh of the installed applications.
 */
static void trigger_apps_refresh(UiAppContext *ctx)
{
    ui_applist_set_busy_state(ctx, TRUE, "Scanning installed applications (APT, Snap, Flatpak, Desktop)...");
    app_scanner_scan_all_async(on_scan_finished, ctx);
}

/**
 * Refresh button click callback.
 */
static void on_refresh_button_clicked(GtkButton *button, gpointer user_data)
{
    (void)button;
    UiAppContext *ctx = (UiAppContext *)user_data;
    trigger_apps_refresh(ctx);
}

/**
 * GTK Application activate handler: builds and displays the primary GUI.
 */
static void app_activate(GtkApplication *app, gpointer user_data)
{
    (void)user_data;
    apply_application_css();

    UiAppContext *ctx = g_new0(UiAppContext, 1);

    /* 1. Main Window: 900x600, resizable */
    ctx->window = GTK_APPLICATION_WINDOW(gtk_application_window_new(app));
    gtk_window_set_title(GTK_WINDOW(ctx->window), APP_TITLE);
    gtk_window_set_default_size(GTK_WINDOW(ctx->window), 900, 600);
    gtk_window_set_resizable(GTK_WINDOW(ctx->window), TRUE);
    gtk_window_set_position(GTK_WINDOW(ctx->window), GTK_WIN_POS_CENTER);

    /* 2. Header Bar */
    GtkWidget *header_bar = gtk_header_bar_new();
    gtk_header_bar_set_show_close_button(GTK_HEADER_BAR(header_bar), TRUE);
    gtk_header_bar_set_title(GTK_HEADER_BAR(header_bar), APP_TITLE);
    gtk_header_bar_set_subtitle(GTK_HEADER_BAR(header_bar), "Installed Applications Manager");
    gtk_window_set_titlebar(GTK_WINDOW(ctx->window), header_bar);

    /* Header Bar Left: Refresh button + Spinner */
    GtkWidget *header_left_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6);

    ctx->btn_refresh = gtk_button_new_from_icon_name("view-refresh-symbolic", GTK_ICON_SIZE_BUTTON);
    gtk_widget_set_tooltip_text(ctx->btn_refresh, "Rescan installed packages (APT, Snap, Flatpak)");
    g_signal_connect(ctx->btn_refresh, "clicked", G_CALLBACK(on_refresh_button_clicked), ctx);
    gtk_box_pack_start(GTK_BOX(header_left_box), ctx->btn_refresh, FALSE, FALSE, 0);

    ctx->spinner = GTK_SPINNER(gtk_spinner_new());
    gtk_box_pack_start(GTK_BOX(header_left_box), GTK_WIDGET(ctx->spinner), FALSE, FALSE, 0);

    gtk_header_bar_pack_start(GTK_HEADER_BAR(header_bar), header_left_box);

    /* Header Bar Right: App Menu Button */
    GtkWidget *menu_button = gtk_menu_button_new();
    GtkWidget *menu_icon = gtk_image_new_from_icon_name("open-menu-symbolic", GTK_ICON_SIZE_BUTTON);
    gtk_button_set_image(GTK_BUTTON(menu_button), menu_icon);

    GtkWidget *menu = gtk_menu_new();
    GtkWidget *item_about = gtk_menu_item_new_with_label("About AppClip Manager");
    g_signal_connect(item_about, "activate", G_CALLBACK(on_about_clicked), ctx);
    gtk_menu_shell_append(GTK_MENU_SHELL(menu), item_about);

    GtkWidget *separator = gtk_separator_menu_item_new();
    gtk_menu_shell_append(GTK_MENU_SHELL(menu), separator);

    GtkWidget *item_quit = gtk_menu_item_new_with_label("Quit");
    g_signal_connect_swapped(item_quit, "activate", G_CALLBACK(gtk_widget_destroy), ctx->window);
    gtk_menu_shell_append(GTK_MENU_SHELL(menu), item_quit);

    gtk_widget_show_all(menu);
    gtk_menu_button_set_popup(GTK_MENU_BUTTON(menu_button), menu);
    gtk_header_bar_pack_end(GTK_HEADER_BAR(header_bar), menu_button);

    /* 3. Main Container Layout with GtkOverlay for floating toast */
    GtkWidget *overlay = gtk_overlay_new();
    gtk_container_add(GTK_CONTAINER(ctx->window), overlay);

    GtkWidget *main_vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(overlay), main_vbox);

    /* Top Search Bar container */
    GtkWidget *search_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    gtk_container_set_border_width(GTK_CONTAINER(search_box), 12);

    ctx->search_entry = GTK_SEARCH_ENTRY(gtk_search_entry_new());
    gtk_entry_set_placeholder_text(GTK_ENTRY(ctx->search_entry), "Search installed applications by name, package ID, or source...");
    gtk_box_pack_start(GTK_BOX(search_box), GTK_WIDGET(ctx->search_entry), TRUE, TRUE, 0);

    gtk_box_pack_start(GTK_BOX(main_vbox), search_box, FALSE, FALSE, 0);

    /* Progress Bar for async operation status (pulse mode) */
    ctx->progress_bar = GTK_PROGRESS_BAR(gtk_progress_bar_new());
    gtk_widget_set_no_show_all(GTK_WIDGET(ctx->progress_bar), TRUE);
    gtk_box_pack_start(GTK_BOX(main_vbox), GTK_WIDGET(ctx->progress_bar), FALSE, FALSE, 0);

    /* 4. Scrolled Window containing GtkListBox */
    GtkWidget *scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
                                   GTK_POLICY_NEVER,
                                   GTK_POLICY_AUTOMATIC);
    gtk_box_pack_start(GTK_BOX(main_vbox), scrolled_window, TRUE, TRUE, 0);

    ctx->list_box = GTK_LIST_BOX(gtk_list_box_new());
    gtk_list_box_set_selection_mode(ctx->list_box, GTK_SELECTION_NONE);

    /* Set up real-time search filter function */
    gtk_list_box_set_filter_func(ctx->list_box, ui_applist_filter_func, ctx, NULL);
    g_signal_connect_swapped(ctx->search_entry, "search-changed",
                             G_CALLBACK(gtk_list_box_invalidate_filter), ctx->list_box);

    gtk_container_add(GTK_CONTAINER(scrolled_window), GTK_WIDGET(ctx->list_box));

    /* 5. Bottom Status Bar */
    GtkWidget *statusbar_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    gtk_container_set_border_width(GTK_CONTAINER(statusbar_box), 8);

    ctx->statusbar_label = gtk_label_new("Ready");
    gtk_label_set_xalign(GTK_LABEL(ctx->statusbar_label), 0.0);
    GtkStyleContext *st_ctx = gtk_widget_get_style_context(ctx->statusbar_label);
    gtk_style_context_add_class(st_ctx, "size-label");
    gtk_box_pack_start(GTK_BOX(statusbar_box), ctx->statusbar_label, TRUE, TRUE, 4);

    GtkWidget *author_label = gtk_label_new("AppClip Manager • by Jeyaul Hoque");
    gtk_label_set_xalign(GTK_LABEL(author_label), 1.0);
    GtkStyleContext *ath_ctx = gtk_widget_get_style_context(author_label);
    gtk_style_context_add_class(ath_ctx, "size-label");
    gtk_box_pack_end(GTK_BOX(statusbar_box), author_label, FALSE, FALSE, 4);

    GtkWidget *sep_bottom = gtk_separator_new(GTK_ORIENTATION_HORIZONTAL);
    gtk_box_pack_start(GTK_BOX(main_vbox), sep_bottom, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(main_vbox), statusbar_box, FALSE, FALSE, 0);

    /* 6. Floating Success Toast Notification (GtkRevealer in GtkOverlay) */
    ctx->toast_revealer = gtk_revealer_new();
    gtk_revealer_set_transition_type(GTK_REVEALER(ctx->toast_revealer), GTK_REVEALER_TRANSITION_TYPE_SLIDE_UP);
    gtk_widget_set_halign(ctx->toast_revealer, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(ctx->toast_revealer, GTK_ALIGN_END);

    GtkWidget *toast_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    GtkStyleContext *tctx = gtk_widget_get_style_context(toast_box);
    gtk_style_context_add_class(tctx, "toast-container");

    GtkWidget *check_icon = gtk_image_new_from_icon_name("emblem-ok-symbolic", GTK_ICON_SIZE_BUTTON);
    gtk_box_pack_start(GTK_BOX(toast_box), check_icon, FALSE, FALSE, 0);

    ctx->toast_label = gtk_label_new("App uninstalled successfully");
    gtk_box_pack_start(GTK_BOX(toast_box), ctx->toast_label, FALSE, FALSE, 0);

    gtk_container_add(GTK_CONTAINER(ctx->toast_revealer), toast_box);
    gtk_overlay_add_overlay(GTK_OVERLAY(overlay), ctx->toast_revealer);

    /* Show all UI components except no-show widgets */
    gtk_widget_show_all(GTK_WIDGET(ctx->window));

    /* Trigger initial scan */
    trigger_apps_refresh(ctx);
}

int main(int argc, char *argv[])
{
    GtkApplication *app = gtk_application_new(APP_ID, G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", G_CALLBACK(app_activate), NULL);

    int status = g_application_run(G_APPLICATION(app), argc, argv);
    g_object_unref(app);

    return status;
}
